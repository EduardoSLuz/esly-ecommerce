---
name: Other issues
about: If the other templates don't fit...
title: ''
labels: ''
assignees: ''

---

⚠️ Search for existing open/closed issues/discussions before you open your issue.
