# lazysizes plugins/extensions/snippets

**lazysizes** works out of the box with standard and responsive images (``src``, ``srcset`` and ``picture``) and iframes.

The scripts in this folder can be used as extensions or as boilerplate snippets to extend and adjust lazysizes to your needs. 
